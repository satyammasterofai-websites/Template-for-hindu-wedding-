'use client';

import { useState, useEffect } from 'react';
import { db, auth, googleProvider } from '@/lib/firebase';
import { signInWithPopup, signOut, onAuthStateChanged, User } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { useRouter } from 'next/navigation';

export default function AdminPanel() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  const [data, setData] = useState({
    mantraAudioBase64: '',
    mainAudioBase64: '',
    brideName: 'Ananya',
    groomName: 'Siddharth',
    ceremonies: [
      { name: "Haldi", hindiName: "हल्दी", date: "14th December 2026", time: "10:00 AM", venue: "The Royal Palace Gardens, New Delhi", emoji: "🌻" },
      { name: "Mehendi", hindiName: "मेहंदी", date: "14th December 2026", time: "04:00 PM", venue: "The Royal Palace Courtyard, New Delhi", emoji: "🌿" },
      { name: "Sangeet", hindiName: "संगीत", date: "15th December 2026", time: "07:00 PM", venue: "Grand Ballroom, The Royal Palace, New Delhi", emoji: "🥁" },
      { name: "Wedding", hindiName: "विवाह", date: "16th December 2026", time: "08:00 PM", venue: "Mandapam, The Royal Palace, New Delhi", emoji: "🪔" },
    ]
  });

  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
      if (currentUser?.email === 'satyammasterofai@gmail.com') {
        loadData();
      }
    });
    return () => unsubscribe();
  }, []);

  const loadData = async () => {
    try {
      const docRef = doc(db, 'invitation', 'main');
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setData(docSnap.data() as any);
      }
    } catch (error) {
      console.error("Error loading data", error);
    }
  };

  const saveData = async () => {
    setSaving(true);
    try {
      await setDoc(doc(db, 'invitation', 'main'), data);
      alert('Saved successfully!');
    } catch (error: any) {
      console.error("Error saving data", error);
      alert('Error saving data: ' + error.message);
    }
    setSaving(false);
  };

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Error logging in", error);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, field: string) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setData({ ...data, [field]: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCeremonyChange = (index: number, field: string, value: string) => {
    const newCeremonies = [...data.ceremonies];
    newCeremonies[index] = { ...newCeremonies[index], [field]: value };
    setData({ ...data, ceremonies: newCeremonies });
  };

  const addCeremony = () => {
    setData({
      ...data,
      ceremonies: [...data.ceremonies, { name: "New Event", hindiName: "नया आयोजन", date: "", time: "", venue: "", emoji: "✨" }]
    });
  };

  const removeCeremony = (index: number) => {
    const newCeremonies = data.ceremonies.filter((_, i) => i !== index);
    setData({ ...data, ceremonies: newCeremonies });
  };

  if (loading) return <div className="p-8">Loading...</div>;

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="bg-white p-8 rounded-lg shadow-md text-center">
          <h1 className="text-2xl font-bold mb-4">Admin Panel</h1>
          <button onClick={handleLogin} className="bg-blue-600 text-white px-6 py-2 rounded">Login with Google</button>
        </div>
      </div>
    );
  }

  if (user.email !== 'satyammasterofai@gmail.com') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="bg-white p-8 rounded-lg shadow-md text-center">
          <h1 className="text-2xl font-bold mb-4 text-red-600">Access Denied</h1>
          <p className="mb-4">You do not have permission to access this panel.</p>
          <button onClick={handleLogout} className="bg-gray-600 text-white px-6 py-2 rounded">Logout</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8 font-sans text-gray-900">
      <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow">
        <div className="flex justify-between items-center mb-8 border-b pb-4">
          <h1 className="text-3xl font-bold">Template Admin Panel</h1>
          <div className="flex gap-4">
            <button onClick={() => router.push('/')} className="bg-gray-200 text-gray-800 px-4 py-2 rounded hover:bg-gray-300">
              Back to Website
            </button>
            <button onClick={handleLogout} className="bg-red-100 text-red-600 px-4 py-2 rounded hover:bg-red-200">
              Logout
            </button>
          </div>
        </div>

        <div className="space-y-8">
          <section>
            <h2 className="text-xl font-bold mb-4 border-b pb-2">Names</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Bride Name</label>
                <input 
                  type="text" 
                  value={data.brideName} 
                  onChange={e => setData({...data, brideName: e.target.value})}
                  className="w-full border rounded p-2"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Groom Name</label>
                <input 
                  type="text" 
                  value={data.groomName} 
                  onChange={e => setData({...data, groomName: e.target.value})}
                  className="w-full border rounded p-2"
                />
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-bold mb-4 border-b pb-2">Audio Uploads (Base64)</h2>
            <p className="text-sm text-gray-500 mb-4">Note: Uploading large files in Base64 may exceed Firestore limits (1MB). Please use compressed MP3s.</p>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Mantra Audio (approx. 18s)</label>
                <input type="file" accept="audio/*" onChange={e => handleFileChange(e, 'mantraAudioBase64')} className="w-full border rounded p-2" />
                {data.mantraAudioBase64 && <audio src={data.mantraAudioBase64} controls className="mt-2" />}
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Main Audio (Background Song)</label>
                <input type="file" accept="audio/*" onChange={e => handleFileChange(e, 'mainAudioBase64')} className="w-full border rounded p-2" />
                {data.mainAudioBase64 && <audio src={data.mainAudioBase64} controls className="mt-2" />}
              </div>
            </div>
          </section>

          <section>
            <div className="flex justify-between items-center mb-4 border-b pb-2">
              <h2 className="text-xl font-bold">Ceremonies / Events</h2>
              <button onClick={addCeremony} className="bg-green-600 text-white px-3 py-1 rounded text-sm">+ Add Event</button>
            </div>
            
            <div className="space-y-6">
              {data.ceremonies.map((event, index) => (
                <div key={index} className="border p-4 rounded bg-gray-50 relative">
                  <button onClick={() => removeCeremony(index)} className="absolute top-4 right-4 text-red-500 hover:text-red-700 text-sm font-bold">Remove</button>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Name (English)</label>
                      <input type="text" value={event.name} onChange={e => handleCeremonyChange(index, 'name', e.target.value)} className="w-full border rounded p-2" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Name (Hindi)</label>
                      <input type="text" value={event.hindiName} onChange={e => handleCeremonyChange(index, 'hindiName', e.target.value)} className="w-full border rounded p-2" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Date</label>
                      <input type="text" value={event.date} onChange={e => handleCeremonyChange(index, 'date', e.target.value)} className="w-full border rounded p-2" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Time</label>
                      <input type="text" value={event.time} onChange={e => handleCeremonyChange(index, 'time', e.target.value)} className="w-full border rounded p-2" />
                    </div>
                    <div className="col-span-2">
                      <label className="block text-sm font-medium mb-1">Venue</label>
                      <input type="text" value={event.venue} onChange={e => handleCeremonyChange(index, 'venue', e.target.value)} className="w-full border rounded p-2" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Emoji</label>
                      <input type="text" value={event.emoji} onChange={e => handleCeremonyChange(index, 'emoji', e.target.value)} className="w-full border rounded p-2" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <div className="pt-8 border-t">
            <button 
              onClick={saveData} 
              disabled={saving}
              className="w-full bg-blue-600 text-white font-bold py-3 rounded hover:bg-blue-700 disabled:opacity-50"
            >
              {saving ? 'Saving...' : 'Save All Changes'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
