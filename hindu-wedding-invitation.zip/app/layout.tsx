import type {Metadata} from 'next';
import { Playfair_Display, Noto_Serif_Devanagari, Great_Vibes } from 'next/font/google';
import './globals.css';

const playfair = Playfair_Display({ subsets: ['latin'], variable: '--font-playfair' });
const notoHindi = Noto_Serif_Devanagari({ weight: ['400', '700'], subsets: ['devanagari'], variable: '--font-noto-hindi' });
const greatVibes = Great_Vibes({ weight: '400', subsets: ['latin'], variable: '--font-great-vibes' });

export const metadata: Metadata = {
  title: 'Hindu Wedding Invitation',
  description: 'You are cordially invited to our wedding',
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`${playfair.variable} ${notoHindi.variable} ${greatVibes.variable}`}>
      <body className="font-playfair antialiased" suppressHydrationWarning>{children}</body>
    </html>
  );
}
