'use client';

import { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Clock, CalendarHeart, Music, Sparkles, Volume2, VolumeX, Settings } from 'lucide-react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import Link from 'next/link';

const FallingPetals = () => {
  const [mounted, setMounted] = useState(false);
  const [windowWidth, setWindowWidth] = useState(1000);
  const [windowHeight, setWindowHeight] = useState(800);

  const [petals, setPetals] = useState<any[]>([]);

  useEffect(() => {
    setMounted(true);
    setWindowWidth(window.innerWidth);
    setWindowHeight(window.innerHeight);
    
    setPetals([...Array(25)].map(() => ({
      startX: Math.random(),
      startRotate: Math.random() * 360,
      scale: 0.5 + Math.random() * 0.8,
      endX: Math.random(),
      endRotate: Math.random() * 720,
      duration: 7 + Math.random() * 8,
      delay: Math.random() * 10
    })));

    const handleResize = () => {
      setWindowWidth(window.innerWidth);
      setWindowHeight(window.innerHeight);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  if (!mounted) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-10 overflow-hidden">
      {petals.map((p, i) => (
        <motion.div
          key={i}
          className="absolute text-[#b91c1c]/60 drop-shadow-md z-30"
          initial={{
            y: -50,
            x: p.startX * windowWidth,
            rotate: p.startRotate,
            scale: p.scale
          }}
          animate={{
            y: windowHeight + 100,
            x: p.endX * windowWidth,
            rotate: p.endRotate,
          }}
          transition={{
            duration: p.duration,
            repeat: Infinity,
            ease: "linear",
            delay: p.delay
          }}
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
          </svg>
        </motion.div>
      ))}
    </div>
  );
};

const EventCard = ({ event, index }: { event: any, index: number }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50, rotateX: -20 }}
      whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.8, delay: index * 0.2, ease: "easeOut" }}
      className={`relative rounded-xl p-8 shadow-xl border-[2px] max-w-xl mx-auto w-full my-8 group overflow-hidden ${event.gradient} ${event.borderColor}`}
    >
      <div className={`absolute top-2 left-2 w-6 h-6 border-t-2 border-l-2 opacity-50 ${event.cornerColor}`}></div>
      <div className={`absolute top-2 right-2 w-6 h-6 border-t-2 border-r-2 opacity-50 ${event.cornerColor}`}></div>
      <div className={`absolute bottom-2 left-2 w-6 h-6 border-b-2 border-l-2 opacity-50 ${event.cornerColor}`}></div>
      <div className={`absolute bottom-2 right-2 w-6 h-6 border-b-2 border-r-2 opacity-50 ${event.cornerColor}`}></div>

      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
        <event.icon size={64} className={event.iconColor} />
      </div>
      
      <h3 className={`font-noto-hindi text-3xl font-bold mb-1 ${event.textColor}`}>{event.hindiName}</h3>
      <div className="flex items-center gap-3 mb-6">
        <h4 className={`text-2xl font-bold tracking-widest uppercase ${event.textColor}`}>{event.name}</h4>
        <span className="text-2xl">{event.emoji}</span>
      </div>
      
      <div className="space-y-4 text-[#111]">
        <div className="flex items-center space-x-4">
          <CalendarHeart className={event.iconColor} size={24} />
          <span className="text-lg font-semibold">{event.date}</span>
        </div>
        <div className="flex items-center space-x-4">
          <Clock className={event.iconColor} size={24} />
          <span className="text-lg">{event.time}</span>
        </div>
        <div className="flex items-start space-x-4">
          <MapPin className={`${event.iconColor} mt-1 shrink-0`} size={24} />
          <span className="text-lg leading-relaxed text-[#555]">{event.venue}</span>
        </div>
      </div>
    </motion.div>
  );
};

export default function WeddingInvitation() {
  const [isOpen, setIsOpen] = useState(false);
  const [showMantra, setShowMantra] = useState(false);
  const [showMainContent, setShowMainContent] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeAudio, setActiveAudio] = useState<'none' | 'mantra' | 'main'>('none');
  const audioMantraRef = useRef<HTMLAudioElement | null>(null);
  const audioMainRef = useRef<HTMLAudioElement | null>(null);

  const [data, setData] = useState({
    mantraAudioBase64: '',
    mainAudioBase64: '',
    brideName: 'Ananya',
    groomName: 'Siddharth',
    ceremonies: [
      { name: "Haldi", hindiName: "हल्दी", date: "14th December 2026", time: "10:00 AM", venue: "The Royal Palace Gardens, New Delhi", emoji: "🌻" },
      { name: "Mehendi", hindiName: "मेहंदी", date: "14th December 2026", time: "04:00 PM", venue: "The Royal Palace Courtyard, New Delhi", emoji: "🌿" },
      { name: "Sangeet", hindiName: "संगीत", date: "15th December 2026", time: "07:00 PM", venue: "Grand Ballroom, The Royal Palace, New Delhi", emoji: "🥁" },
      { name: "Wedding", hindiName: "विवाह", date: "16th December 2026", time: "08:00 PM", venue: "Mandapam, The Royal Palace, New Delhi", emoji: "🪔" },
    ]
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const docSnap = await getDoc(doc(db, 'invitation', 'main'));
        if (docSnap.exists()) {
          setData(docSnap.data() as any);
        }
      } catch (e) {
        console.error("Error fetching data:", e);
      }
    };
    fetchData();
  }, []);

  useEffect(() => {
    // Initialize audio elements. If data has base64 audio, use that, otherwise fallback to local files.
    audioMantraRef.current = new Audio(data.mantraAudioBase64 || "/mantra.mp3");
    audioMainRef.current = new Audio(data.mainAudioBase64 || "/main-audio.mp3");
    if (audioMainRef.current) {
        audioMainRef.current.loop = true;
    }

    return () => {
      if (audioMantraRef.current) {
        audioMantraRef.current.pause();
        audioMantraRef.current = null;
      }
      if (audioMainRef.current) {
        audioMainRef.current.pause();
        audioMainRef.current = null;
      }
    }
  }, [data.mantraAudioBase64, data.mainAudioBase64]);

  useEffect(() => {
    const mantraAudio = audioMantraRef.current;
    const mainAudio = audioMainRef.current;

    if (!mantraAudio || !mainAudio) return;

    if (isPlaying) {
      if (activeAudio === 'mantra') {
        mantraAudio.volume = 0.8;
        mantraAudio.play().catch(e => console.warn("Mantra audio play failed:", e));
        mainAudio.pause();
      } else if (activeAudio === 'main') {
        mainAudio.volume = 0.5;
        mainAudio.play().catch(e => console.warn("Main audio play failed:", e));
        mantraAudio.pause();
      }
    } else {
      mantraAudio.pause();
      mainAudio.pause();
    }
  }, [isPlaying, activeAudio]);

  const handleOpenClick = () => {
    setIsOpen(true);
    setShowMantra(true);
    setIsPlaying(true);
    setActiveAudio('mantra');
    
    setTimeout(() => {
      setShowMantra(false);
      setActiveAudio('main');
      
      setTimeout(() => {
        setShowMainContent(true);
      }, 1000); // Wait for mantra to fade out
    }, 18000); // 18 seconds for mantra
  };

  const mantraLine1 = "वक्रतुण्ड महाकाय सूर्यकोटि समप्रभ।".split(" ");
  const mantraLine2 = "निर्विघ्नं कुरु मे देव सर्वकार्येषु सर्वदा॥".split(" ");

  const gradients = [
    { icon: Sparkles, gradient: "bg-gradient-to-br from-[#FFFDE7] to-[#FFF9C4]", borderColor: "border-[#FBC02D]", textColor: "text-[#F57F17]", iconColor: "text-[#FBC02D]", cornerColor: "border-[#FBC02D]" },
    { icon: Sparkles, gradient: "bg-gradient-to-br from-[#E8F5E9] to-[#C8E6C9]", borderColor: "border-[#388E3C]", textColor: "text-[#1B5E20]", iconColor: "text-[#4CAF50]", cornerColor: "border-[#4CAF50]" },
    { icon: Music, gradient: "bg-gradient-to-br from-[#F3E5F5] to-[#E1BEE7]", borderColor: "border-[#8E24AA]", textColor: "text-[#4A148C]", iconColor: "text-[#9C27B0]", cornerColor: "border-[#9C27B0]" },
    { icon: CalendarHeart, gradient: "bg-gradient-to-br from-[#FFEBEE] to-[#FFCDD2]", borderColor: "border-[#D32F2F]", textColor: "text-[#B71C1C]", iconColor: "text-[#F44336]", cornerColor: "border-[#F44336]" },
  ];

  const events = data.ceremonies.map((ceremony, i) => {
    const style = gradients[i % gradients.length];
    return {
      ...ceremony,
      ...style
    };
  });

  return (
    <div className="min-h-screen bg-[#fdf2f2] overflow-x-hidden selection:bg-[#fff1f2] selection:text-[#b91c1c] relative">
      <div className="fixed top-0 left-0 w-full h-full opacity-10 pointer-events-none" style={{backgroundImage: 'radial-gradient(#d4af37 1px, transparent 1px)', backgroundSize: '30px 30px'}}></div>
      <div className="fixed -top-12 -left-12 w-64 h-64 border-[16px] border-[#d4af37] rounded-full opacity-20 pointer-events-none"></div>
      <div className="fixed -bottom-12 -right-12 w-64 h-64 border-[16px] border-[#d4af37] rounded-full opacity-20 pointer-events-none"></div>

      {isOpen && (
        <button 
          onClick={() => setIsPlaying(!isPlaying)}
          className="fixed top-4 left-4 z-50 p-3 bg-white/80 backdrop-blur-sm border-2 border-[#d4af37] rounded-full shadow-lg text-[#b91c1c] hover:bg-white transition-all cursor-pointer"
        >
          {isPlaying ? <Volume2 size={24} /> : <VolumeX size={24} />}
        </button>
      )}

      <AnimatePresence>
        {!isOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none">
            {/* Top Flap of Envelope */}
            <motion.div
              initial={{ y: 0 }}
              exit={{ y: '-100vh' }}
              transition={{ duration: 1.2, ease: [0.76, 0, 0.24, 1] }}
              className="absolute top-0 left-0 w-full h-1/2 bg-[#fdf2f2] pointer-events-auto border-b-[3px] border-[#d4af37] shadow-2xl flex items-end justify-center pb-12 pattern-mandala"
            >
              <div className="absolute top-4 w-full flex justify-between px-8 opacity-20">
                <Sparkles className="text-yellow-500" size={32} />
                <Sparkles className="text-yellow-500" size={32} />
              </div>
            </motion.div>

            {/* Bottom Flap of Envelope */}
            <motion.div
              initial={{ y: 0 }}
              exit={{ y: '100vh' }}
              transition={{ duration: 1.2, ease: [0.76, 0, 0.24, 1] }}
              className="absolute bottom-0 left-0 w-full h-1/2 bg-[#fdf2f2] pointer-events-auto border-t-[3px] border-[#d4af37] shadow-2xl flex items-start justify-center pt-12 pattern-mandala"
            >
              <div className="absolute bottom-4 w-full flex justify-between px-8 opacity-20">
                <Sparkles className="text-yellow-500" size={32} />
                <Sparkles className="text-yellow-500" size={32} />
              </div>
            </motion.div>

            {/* Seal / Button */}
            <motion.div
              exit={{ scale: 5, opacity: 0 }}
              transition={{ duration: 0.8, ease: "easeInOut" }}
              className="absolute z-50 pointer-events-auto flex flex-col items-center justify-center"
            >
              <button 
                onClick={handleOpenClick}
                className="group relative flex items-center justify-center w-40 h-40 rounded-full bg-[#b91c1c] border-4 border-[#d4af37] shadow-[0_0_40px_rgba(212,175,55,0.4)] hover:shadow-[0_0_60px_rgba(212,175,55,0.8)] hover:scale-105 transition-all duration-300"
              >
                <div className="absolute inset-0 rounded-full bg-white opacity-10 animate-ping" />
                <div className="flex flex-col items-center">
                  <span className="font-noto-hindi text-4xl text-white mb-2 drop-shadow-md">ॐ</span>
                  <span className="text-xs tracking-[0.2em] text-white font-bold uppercase text-center w-24 leading-tight">Open<br/>Invitation</span>
                </div>
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showMantra && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5 }}
            className="fixed inset-0 z-40 flex flex-col items-center justify-center p-6 text-center"
            style={{
              backgroundColor: '#e6d5b8',
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='200' height='200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='a'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.04' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='200' height='200' filter='url(%23a)' opacity='0.15'/%3E%3C/svg%3E")`,
            }}
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 2, delay: 0.5, ease: "easeOut" }}
              className="max-w-2xl"
            >
              <div className="mb-8 text-[#8b4513]">
                <svg className="w-24 h-24 mx-auto" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" viewBox="0 0 100 100">
                  <path d="M 35 30 L 65 30 L 60 15 L 50 5 L 40 15 Z" fill="currentColor" fillOpacity="0.1" />
                  <path d="M 40 25 L 60 25 M 45 15 L 55 15" />
                  <path d="M 35 30 C 10 20, 0 60, 35 65" fill="currentColor" fillOpacity="0.1" />
                  <path d="M 65 30 C 90 20, 100 60, 65 65" fill="currentColor" fillOpacity="0.1" />
                  <path d="M 35 30 C 35 50, 45 50, 45 50 L 45 75 C 45 85, 30 80, 35 70 C 38 65, 55 75, 55 65 L 55 50 C 55 50, 65 50, 65 30" fill="currentColor" fillOpacity="0.1" />
                  <path d="M 35 55 L 25 60" />
                  <path d="M 65 55 L 70 58" />
                  <circle cx="40" cy="42" r="1.5" fill="currentColor" stroke="none" />
                  <circle cx="60" cy="42" r="1.5" fill="currentColor" stroke="none" />
                  <path d="M 47 35 L 53 35 M 47 38 L 53 38 M 50 35 L 50 42" strokeWidth="1" />
                </svg>
              </div>
              <motion.div 
                initial="hidden"
                animate="visible"
                variants={{
                  visible: { transition: { staggerChildren: 1.4, delayChildren: 1.5 } }
                }}
                className="font-noto-hindi text-3xl md:text-5xl text-[#8b4513] leading-[1.8] md:leading-[1.8] font-bold text-center" 
                style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.1)' }}
              >
                {mantraLine1.map((word, i) => (
                  <motion.span
                    key={`l1-${i}`}
                    variants={{
                      hidden: { opacity: 0, y: 20 },
                      visible: { opacity: 1, y: 0, transition: { duration: 1.5, ease: "easeOut" } }
                    }}
                    className="inline-block mx-2 md:mx-3 mb-4"
                  >
                    {word}
                  </motion.span>
                ))}
                <br className="hidden md:block" />
                {mantraLine2.map((word, i) => (
                  <motion.span
                    key={`l2-${i}`}
                    variants={{
                      hidden: { opacity: 0, y: 20 },
                      visible: { opacity: 1, y: 0, transition: { duration: 1.5, ease: "easeOut" } }
                    }}
                    className="inline-block mx-2 md:mx-3"
                  >
                    {word}
                  </motion.span>
                ))}
              </motion.div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {showMainContent && (
        <motion.main 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.5 }}
          className="relative pb-32"
        >
          <FallingPetals />
          
          <div className="relative z-20 max-w-4xl mx-auto my-12 bg-white border-[3px] border-[#d4af37] p-1 shadow-2xl">
            <div className="border-[1px] border-[#d4af37] flex flex-col items-center px-6 py-24 relative w-full">
              <div className="absolute top-4 left-4 w-16 h-16 border-t-2 border-l-2 border-[#b91c1c]"></div>
              <div className="absolute top-4 right-4 w-16 h-16 border-t-2 border-r-2 border-[#b91c1c]"></div>
              <div className="absolute bottom-4 left-4 w-16 h-16 border-b-2 border-l-2 border-[#b91c1c]"></div>
              <div className="absolute bottom-4 right-4 w-16 h-16 border-b-2 border-r-2 border-[#b91c1c]"></div>
            
            {/* Header section with Om & Shloka */}
            <motion.div
              initial={{ filter: 'blur(10px)', opacity: 0, y: -20 }}
              whileInView={{ filter: 'blur(0px)', opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1.5, delay: 0.5 }}
              className="mb-16 text-center text-center"
            >
              <div className="mb-4 w-24 h-24 mx-auto text-[#d4af37]">
                <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  {/* Crown */}
                  <path d="M 35 30 L 65 30 L 60 15 L 50 5 L 40 15 Z" fill="currentColor" fillOpacity="0.1" />
                  <path d="M 40 25 L 60 25 M 45 15 L 55 15" />
                  
                  {/* Ears */}
                  <path d="M 35 30 C 10 20, 0 60, 35 65" fill="currentColor" fillOpacity="0.1" />
                  <path d="M 65 30 C 90 20, 100 60, 65 65" fill="currentColor" fillOpacity="0.1" />
                  
                  {/* Face & Trunk */}
                  <path d="M 35 30 C 35 50, 45 50, 45 50 L 45 75 C 45 85, 30 80, 35 70 C 38 65, 55 75, 55 65 L 55 50 C 55 50, 65 50, 65 30" fill="currentColor" fillOpacity="0.1" />
                  
                  {/* Tusks */}
                  <path d="M 35 55 L 25 60" /> {/* Left full tusk */}
                  <path d="M 65 55 L 70 58" /> {/* Right broken tusk */}
                  
                  {/* Eyes */}
                  <circle cx="40" cy="42" r="1.5" fill="currentColor" stroke="none" />
                  <circle cx="60" cy="42" r="1.5" fill="currentColor" stroke="none" />
                  
                  {/* Tilak */}
                  <path d="M 47 35 L 53 35 M 47 38 L 53 38 M 50 35 L 50 42" strokeWidth="1" />
                </svg>
              </div>
              <p className="text-[#b91c1c] text-sm tracking-[0.3em] font-bold mb-1">।। श्री गणेशाय नमः ।।</p>
              <p className="text-[#d4af37] italic text-xs mb-4">वक्रतुण्ड महाकाय सूर्यकोटि समप्रभ। निर्विघ्नं कुरु मे देव सर्वकार्येषु सर्वदा॥</p>
              <h2 className="font-noto-hindi text-4xl md:text-5xl text-[#b91c1c] font-black tracking-widest uppercase mb-4" style={{textShadow: '2px 2px 0px #d4af37'}}>शुभ विवाह</h2>
              <div className="h-[2px] w-48 bg-gradient-to-r from-transparent via-[#d4af37] to-transparent mx-auto"></div>
            </motion.div>

            {/* English Invitation text */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1.2 }}
              className="mb-16 text-center"
            >
              <p className="text-[#7f1d1d] text-lg font-medium mb-4 italic">With the divine blessings of our ancestors, we cordially invite you to the auspicious wedding ceremony of</p>
            </motion.div>

            {/* Bride & Groom Names */}
            <motion.div
              initial={{ opacity: 0, y: 50, rotateX: 20 }}
              whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1.5, type: 'spring' }}
              className="my-16 flex flex-col md:flex-row items-center justify-center gap-6"
            >
              <h1 className="font-great-vibes text-7xl md:text-8xl text-[#b91c1c] font-bold italic tracking-tighter">Siddharth</h1>
              <span className="text-3xl md:text-4xl text-[#d4af37] font-serif font-light underline decoration-red-700">weds</span>
              <h1 className="font-great-vibes text-7xl md:text-8xl text-[#b91c1c] font-bold italic tracking-tighter">Ananya</h1>
            </motion.div>

            {/* Hindi Tagline */}
            <motion.div
               initial={{ opacity: 0, x: -100 }}
               whileInView={{ opacity: 1, x: 0 }}
               viewport={{ once: true }}
               transition={{ duration: 1 }}
               className="mb-24 flex flex-col items-center justify-center text-center"
            >
              <div className="border-y-[2px] border-[#d4af37] py-4 px-12">
                <p className="font-noto-hindi text-[#b91c1c] text-xl font-bold">परमेश्वर की असीम अनुकम्पा से हमारे यहाँ मांगलिक उत्सव हो रहा है।</p>
              </div>
            </motion.div>

            {/* Events Timeline */}
            <div className="relative mb-24 w-full text-center">
               {/* Vertical line for desktop */}
               <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-[2px] bg-gradient-to-b from-transparent via-[#d4af37] to-transparent transform -translate-x-1/2"></div>
               
               <motion.h2 
                 initial={{ opacity: 0 }}
                 whileInView={{ opacity: 1 }}
                 viewport={{ once: true }}
                 className="text-4xl uppercase tracking-[0.2em] text-[#b91c1c] font-black mb-16" style={{textShadow: '1px 1px 0px #d4af37'}}
               >
                 Ceremonies
               </motion.h2>

               {events.map((event, i) => (
                 <EventCard key={i} event={event} index={i} />
               ))}
            </div>

            {/* Footer */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1 }}
              className="mt-16 pt-16 flex flex-col items-center text-center w-full"
            >
              <div className="text-[#d4af37] mb-2">
                <svg className="w-8 h-8 mx-auto" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5a2.5 2.5 0 0 1 0-5 2.5 2.5 0 0 1 0 5z"/></svg>
              </div>
              <p className="text-[#111] font-bold text-xl">The Royal Orchid Palace</p>
              <p className="text-[#666] text-sm italic mt-1 mb-8">Lutyens&apos; Delhi, Heritage Block, New Delhi - 110001</p>
              
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <div className="bg-[#b91c1c] text-white px-8 py-3 rounded-full text-sm font-bold tracking-widest shadow-xl border-2 border-[#d4af37] transform hover:scale-105 transition-all cursor-pointer">
                  SAVE THE DATE
                </div>
                <a 
                  href="https://maps.google.com/?q=The+Royal+Orchid+Palace,+Lutyens'+Delhi,+New+Delhi"
                  target="_blank" rel="noopener noreferrer"
                  className="bg-white text-[#b91c1c] px-8 py-3 rounded-full text-sm font-bold tracking-widest shadow-xl border-2 border-[#d4af37] transform hover:scale-105 transition-all cursor-pointer flex items-center gap-2"
                >
                  <MapPin size={18} /> GET DIRECTIONS
                </a>
              </div>

              <div className="mt-12 text-[#d4af37] text-[10px] uppercase tracking-[0.5em] font-bold">दर्शन अभिलाषी: समस्त परिवार</div>
            </motion.div>

            </div>
          </div>
        </motion.main>
      )}
    </div>
  );
}
