import { initializeApp, getApps, getApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";
import { getAuth, GoogleAuthProvider } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyDkzjWey97X_zHzx8N7NK5fu7QBmZsxDcU",
  authDomain: "invitations-templates.firebaseapp.com",
  projectId: "invitations-templates",
  storageBucket: "invitations-templates.firebasestorage.app",
  messagingSenderId: "70649295667",
  appId: "1:70649295667:web:636ac9abcdd74582928446",
  measurementId: "G-F59SX2G2DE"
};

// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const db = getFirestore(app);
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

let analytics;
if (typeof window !== "undefined") {
  analytics = getAnalytics(app);
}

export { app, analytics, db, auth, googleProvider };
